README

Twilio API Documentation
https://www.twilio.com/docs/lookup/api

URL: https://lookups.twilio.com/v1/PhoneNumbers/{phoneNumber}
Username: AC4630f90e7857265f645106d150257e6d
Password: b4c48fec2e5fe9db5b7b43f01c564806