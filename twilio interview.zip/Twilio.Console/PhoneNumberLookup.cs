﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;

namespace Twilio.Console
{
    public class PhoneNumberLookup
    {
        public static bool IsPhoneNumberValid(string phoneNumber)
        {
            throw new NotImplementedException();
        }

        // Implement get Details method

        // 1. Need Country
        // 2. Carrier
        // 3. Phone Number
        // 4. Is Phone Number Valid
        // 5. Type
        public static string GetJSONStringData(string url, string id, string password)
        {
            throw new NotImplementedException();
        }
       
    }
}
